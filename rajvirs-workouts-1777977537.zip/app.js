const muscles = [
  { id: "chest", name: "Chest", note: "press" },
  { id: "back", name: "Back", note: "pull" },
  { id: "shoulders", name: "Shoulders", note: "raise" },
  { id: "arms", name: "Arms", note: "curl" },
  { id: "legs", name: "Legs", note: "squat" },
  { id: "core", name: "Core", note: "brace" },
  { id: "glutes", name: "Glutes", note: "hinge" },
  { id: "cardio", name: "Cardio", note: "sweat" },
];

const storageKey = "fitshare-log-v1";
const profileKey = "fitshare-profile-v1";
const intensityMet = {
  light: 3.8,
  moderate: 5.2,
  hard: 7.0,
};

const els = {
  form: document.querySelector("#trackerForm"),
  date: document.querySelector("#logDate"),
  weight: document.querySelector("#weight"),
  height: document.querySelector("#height"),
  age: document.querySelector("#age"),
  gender: document.querySelector("#gender"),
  steps: document.querySelector("#steps"),
  minutes: document.querySelector("#minutes"),
  intensity: document.querySelector("#intensity"),
  muscleGrid: document.querySelector("#muscleGrid"),
  calorieTotal: document.querySelector("#calorieTotal"),
  restCalories: document.querySelector("#restCalories"),
  stepCalories: document.querySelector("#stepCalories"),
  gymCalories: document.querySelector("#gymCalories"),
  muscleCount: document.querySelector("#muscleCount"),
  weekTotal: document.querySelector("#weekTotal"),
  weekChart: document.querySelector("#weekChart"),
  historyList: document.querySelector("#historyList"),
  shareButton: document.querySelector("#shareButton"),
  clearHistory: document.querySelector("#clearHistory"),
  resetButton: document.querySelector("#resetButton"),
  toast: document.querySelector("#toast"),
};

const today = new Date().toISOString().slice(0, 10);
let selectedMuscles = new Set();
let logs = loadLogs();
let toastTimer;

init();

function init() {
  els.date.value = today;
  renderMuscles();
  loadProfile();
  const openedSharedLog = applySharedLog();
  if (!openedSharedLog) hydrateFromExistingDate();
  updateEstimate();
  renderHistory();
  renderWeek();

  els.form.addEventListener("input", handleInput);
  els.form.addEventListener("change", handleInput);
  els.form.addEventListener("submit", saveDay);
  els.shareButton.addEventListener("click", shareSummary);
  els.clearHistory.addEventListener("click", clearHistory);
  els.resetButton.addEventListener("click", resetForm);
  els.date.addEventListener("change", hydrateFromExistingDate);
}

function renderMuscles() {
  els.muscleGrid.innerHTML = muscles
    .map(
      (muscle) => `
        <button class="muscle-chip" type="button" data-muscle="${muscle.id}" aria-pressed="false">
          ${muscle.name}
          <small>${muscle.note}</small>
        </button>
      `,
    )
    .join("");

  els.muscleGrid.addEventListener("click", (event) => {
    const button = event.target.closest("[data-muscle]");
    if (!button) return;
    const id = button.dataset.muscle;
    if (selectedMuscles.has(id)) {
      selectedMuscles.delete(id);
    } else {
      selectedMuscles.add(id);
    }
    syncMuscleButtons();
    updateEstimate();
  });
}

function handleInput() {
  persistProfile();
  updateEstimate();
}

function getFormData() {
  const weight = numberFrom(els.weight.value);
  const steps = numberFrom(els.steps.value);
  const minutes = numberFrom(els.minutes.value);
  const height = numberFrom(els.height.value);
  const age = numberFrom(els.age.value);
  const restCalories = calculateRestingBurn(weight, height, age, els.gender.value);
  const stepDistanceKm = steps * 0.000762;
  const stepCalories = weight ? stepDistanceKm * weight * 0.53 : 0;
  const muscleFactor = 1 + Math.min(selectedMuscles.size, 8) * 0.025;
  const gymCalories = weight ? intensityMet[els.intensity.value] * weight * (minutes / 60) * muscleFactor : 0;
  const totalCalories = Math.round(restCalories + stepCalories + gymCalories);

  return {
    date: els.date.value || today,
    weight,
    height,
    age,
    gender: els.gender.value,
    steps,
    minutes,
    intensity: els.intensity.value,
    muscles: [...selectedMuscles],
    restCalories: Math.round(restCalories),
    stepCalories: Math.round(stepCalories),
    gymCalories: Math.round(gymCalories),
    totalCalories,
  };
}

function updateEstimate() {
  const data = getFormData();
  els.calorieTotal.textContent = data.totalCalories.toLocaleString();
  els.restCalories.textContent = data.restCalories.toLocaleString();
  els.stepCalories.textContent = data.stepCalories.toLocaleString();
  els.gymCalories.textContent = data.gymCalories.toLocaleString();
  els.muscleCount.textContent = `${data.muscles.length} ${data.muscles.length === 1 ? "muscle" : "muscles"}`;
}

function saveDay(event) {
  event.preventDefault();
  const data = getFormData();

  if (!data.weight || !data.steps && !data.minutes) {
    showToast("Add your weight and either steps or gym time first.");
    return;
  }

  logs = [data, ...logs.filter((log) => log.date !== data.date)]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 30);

  localStorage.setItem(storageKey, JSON.stringify(logs));
  renderHistory();
  renderWeek();
  showToast("Saved today's log.");
}

async function shareSummary() {
  const data = getFormData();
  const muscleNames = data.muscles.map((id) => muscles.find((muscle) => muscle.id === id)?.name).filter(Boolean);
  const shareUrl = new URL(window.location.href);
  shareUrl.searchParams.set("share", btoa(encodeURIComponent(JSON.stringify(data))));

  const text = [
    `Rajvir's Workouts - ${formatDate(data.date)}`,
    `${data.steps.toLocaleString()} steps`,
    `${data.totalCalories.toLocaleString()} approx daily calories burned`,
    `Muscles hit: ${muscleNames.length ? muscleNames.join(", ") : "none logged"}`,
    shareUrl.toString(),
  ].join("\n");

  try {
    if (navigator.share) {
      await navigator.share({ title: "My Rajvir's Workouts log", text, url: shareUrl.toString() });
      showToast("Share sheet opened.");
    } else {
      await copyToClipboard(text);
      showToast("Summary copied. Send it to your friend.");
    }
  } catch (error) {
    const copied = await copyToClipboard(text);
    showToast(copied ? "Summary copied. Send it to your friend." : "Share summary is ready, but copying was blocked.");
  }
}

function renderHistory() {
  if (!logs.length) {
    els.historyList.innerHTML = `
      <article class="history-item">
        <div>
          <strong>No saved days yet</strong>
          <span>Save today to start your log.</span>
        </div>
      </article>
    `;
    return;
  }

  els.historyList.innerHTML = logs
    .slice(0, 5)
    .map(
      (log) => `
        <article class="history-item">
          <div>
            <strong>${formatDate(log.date)} · ${log.totalCalories.toLocaleString()} cal</strong>
            <span>${log.steps.toLocaleString()} steps · ${log.muscles.length} muscles · ${log.minutes || 0} min</span>
          </div>
          <button type="button" data-load-date="${log.date}">Load</button>
        </article>
      `,
    )
    .join("");

  els.historyList.querySelectorAll("[data-load-date]").forEach((button) => {
    button.addEventListener("click", () => {
      els.date.value = button.dataset.loadDate;
      hydrateFromExistingDate();
      showToast("Loaded saved day.");
    });
  });
}

function renderWeek() {
  const days = getLastSevenDays();
  const maxSteps = Math.max(1, ...days.map((day) => day.log?.steps || 0));
  const totalSteps = days.reduce((sum, day) => sum + (day.log?.steps || 0), 0);
  els.weekTotal.textContent = `${totalSteps.toLocaleString()} steps`;

  els.weekChart.innerHTML = days
    .map((day) => {
      const steps = day.log?.steps || 0;
      const height = Math.max(10, Math.round((steps / maxSteps) * 122));
      return `
        <div class="bar-wrap" title="${formatDate(day.date)}: ${steps.toLocaleString()} steps">
          <div class="bar" style="height: ${height}px"></div>
          <div class="bar-label">${shortDay(day.date)}</div>
        </div>
      `;
    })
    .join("");
}

function hydrateFromExistingDate() {
  const log = logs.find((item) => item.date === els.date.value);
  if (!log) {
    selectedMuscles = new Set();
    els.steps.value = "";
    els.minutes.value = "";
    els.intensity.value = "moderate";
    syncMuscleButtons();
    updateEstimate();
    return;
  }

  els.weight.value = log.weight || "";
  els.height.value = log.height || "";
  els.age.value = log.age || "";
  els.gender.value = log.gender || "male";
  els.steps.value = log.steps || "";
  els.minutes.value = log.minutes || "";
  els.intensity.value = log.intensity || "moderate";
  selectedMuscles = new Set(log.muscles || []);
  syncMuscleButtons();
  updateEstimate();
}

function syncMuscleButtons() {
  els.muscleGrid.querySelectorAll("[data-muscle]").forEach((button) => {
    const selected = selectedMuscles.has(button.dataset.muscle);
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
}

function resetForm() {
  selectedMuscles = new Set();
  els.date.value = today;
  els.steps.value = "";
  els.minutes.value = "";
  els.intensity.value = "moderate";
  syncMuscleButtons();
  updateEstimate();
  showToast("Today's form cleared.");
}

function clearHistory() {
  logs = [];
  localStorage.removeItem(storageKey);
  renderHistory();
  renderWeek();
  showToast("History cleared.");
}

function loadLogs() {
  try {
    return JSON.parse(localStorage.getItem(storageKey)) || seedLogs();
  } catch {
    return seedLogs();
  }
}

function seedLogs() {
  const dates = getLastSevenDays().map((day) => day.date);
  return [
    { date: dates[5], weight: 75, height: 175, age: 28, gender: "male", steps: 9200, minutes: 55, intensity: "moderate", muscles: ["chest", "arms"], stepCalories: 279, gymCalories: 393, totalCalories: 672 },
    { date: dates[4], weight: 75, height: 175, age: 28, gender: "male", steps: 6800, minutes: 40, intensity: "light", muscles: ["core", "cardio"], stepCalories: 206, gymCalories: 202, totalCalories: 408 },
    { date: dates[2], weight: 75, height: 175, age: 28, gender: "male", steps: 11100, minutes: 70, intensity: "hard", muscles: ["legs", "glutes", "back"], stepCalories: 336, gymCalories: 690, totalCalories: 1026 },
  ];
}

function loadProfile() {
  try {
    const profile = JSON.parse(localStorage.getItem(profileKey));
    if (!profile) return;
    els.weight.value = profile.weight || "";
    els.height.value = profile.height || "";
    els.age.value = profile.age || "";
    els.gender.value = profile.gender || "male";
  } catch {
    localStorage.removeItem(profileKey);
  }
}

function persistProfile() {
  const profile = {
    weight: els.weight.value,
    height: els.height.value,
    age: els.age.value,
    gender: els.gender.value,
  };
  localStorage.setItem(profileKey, JSON.stringify(profile));
}

function applySharedLog() {
  const params = new URLSearchParams(window.location.search);
  const payload = params.get("share");
  if (!payload) return false;

  try {
    const data = JSON.parse(decodeURIComponent(atob(payload)));
    els.date.value = data.date || today;
    els.weight.value = data.weight || "";
    els.height.value = data.height || "";
    els.age.value = data.age || "";
    els.gender.value = data.gender || "male";
    els.steps.value = data.steps || "";
    els.minutes.value = data.minutes || "";
    els.intensity.value = data.intensity || "moderate";
    selectedMuscles = new Set(data.muscles || []);
    showToast("Shared log loaded.");
    return true;
  } catch {
    showToast("That shared log could not be opened.");
    return false;
  }
}

function calculateRestingBurn(weight, height, age, gender) {
  if (!weight || !height || !age) return 0;
  if (gender === "female") return 10 * weight + 6.25 * height - 5 * age - 161;
  if (gender === "male") return 10 * weight + 6.25 * height - 5 * age + 5;
  const male = 10 * weight + 6.25 * height - 5 * age + 5;
  const female = 10 * weight + 6.25 * height - 5 * age - 161;
  return (male + female) / 2;
}

async function copyToClipboard(text) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return legacyCopy(text);
    }
  }
  return legacyCopy(text);
}

function legacyCopy(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  document.body.append(textarea);
  textarea.select();
  let copied = false;
  try {
    copied = document.execCommand("copy");
  } catch {
    copied = false;
  }
  textarea.remove();
  return copied;
}

function getLastSevenDays() {
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - index));
    const iso = date.toISOString().slice(0, 10);
    return {
      date: iso,
      log: logs?.find((item) => item.date === iso),
    };
  });
}

function showToast(message) {
  window.clearTimeout(toastTimer);
  els.toast.textContent = message;
  els.toast.classList.add("is-visible");
  toastTimer = window.setTimeout(() => {
    els.toast.classList.remove("is-visible");
  }, 2400);
}

function numberFrom(value) {
  return Number.parseFloat(value) || 0;
}

function formatDate(value) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(new Date(`${value}T12:00:00`));
}

function shortDay(value) {
  return new Intl.DateTimeFormat("en", { weekday: "short" }).format(new Date(`${value}T12:00:00`)).slice(0, 2);
}
